function setup() {
  createCanvas(1280,720);
}

function draw() {
  background(123, 23, 179 );
  circle(640,100,100);
  square(620, 90, 10);
  square(665, 90, 10);
  point(625, 95);
  point(670, 95);
  line(600, 69, 553, 127);
  line(675, 66, 730, 92);
  line(670, 59, 751, 84);
  line(639, 50, 557, 131);
  triangle(645, 150, 518, 343, 771, 343);
  rect(558, 343, 20, 120);
  rect(721, 343, 20, 120);
  line(585, 245, 520, 205);
  line(707, 245, 620, 205);
  textSize(30)
  text('My Portrait', 10, 30)
  text('Sierra Webster-Robertson', 920, 700)
}